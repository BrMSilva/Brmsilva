package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    // Variável para armazenar a quantidade
    private int contar = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referências para os elementos da interface
        TextView textView4 = findViewById(R.id.textView4);
        Button buttonAdd = findViewById(R.id.button2);
        Button buttonSub = findViewById(R.id.button);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView6 = findViewById(R.id.textView6);
        Button buttonFaz = findViewById(R.id.button3);
        EditText editTextNome = findViewById(R.id.editTextNome);

        //Referências para os checkBoxes
        CheckBox checkBox = findViewById(R.id.checkBox);
        CheckBox checkBox2 = findViewById(R.id.checkBox2);
        CheckBox checkBox3 = findViewById(R.id.checkBox3);

        //botão adicionar
        buttonAdd.setOnClickListener(v -> {
            contar++;
            textView4.setText(String.valueOf(contar));
            ePe(textView6, checkBox, checkBox2, checkBox3);
        });

        //botão subtrair
        buttonSub.setOnClickListener(v -> {
            if (contar > 0) {
                contar--;
                textView4.setText(String.valueOf(contar));
                ePe(textView6, checkBox, checkBox2, checkBox3);
            }
        });

        // Listeners para os CheckBoxes
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) ->
                ePe(textView6, checkBox, checkBox2, checkBox3));

        checkBox2.setOnCheckedChangeListener((buttonView, isChecked) ->
                ePe(textView6, checkBox, checkBox2, checkBox3));

        checkBox3.setOnCheckedChangeListener((buttonView, isChecked) ->
                ePe(textView6, checkBox, checkBox2, checkBox3));

        // Função fazer pedido
        // Primeiro click mostra resumo do pedido
        buttonFaz.setOnClickListener(v -> {
            String nome = getNome(editTextNome);
            List<String> textos = Arrays.asList("Nome do cliente: "+ nome,"Tem Bacon? "+getC(checkBox.isChecked()),
                    "Tem Queijo? "+getC(checkBox2.isChecked()),"Tem Onion Rings? "+getC(checkBox3.isChecked()),"QUANTIDADE: "+getT(textView4));
            StringBuilder textoConcatenado = new StringBuilder();
            for (String texto : textos){
                textoConcatenado.append(texto).append("\n");
            }
            textView5.setText(textoConcatenado.toString().trim());

        // Segundo click chama intent Email
            buttonFaz.setOnClickListener(View -> {
                String uriText =
                        "mailto:hamburguerZ@gmail.com" +
                                "?subject=" + Uri.encode("Pedido de: " + getNome(editTextNome)) +
                                "&body=" + Uri.encode(textoConcatenado.toString().trim())+ "\n" + ePe(textView6);

                Uri uri = Uri.parse(uriText);
                Intent sendIntent = new Intent(Intent.ACTION_SENDTO);
                sendIntent.setData(uri);
                startActivity(Intent.createChooser(sendIntent, "Send email"));
                sendIntent.setData(Uri.parse("mailto"));
                startActivity(sendIntent);
            });
        });

    }

    // Função para calcular o total
    private int calcularTotal(CheckBox checkBox, CheckBox checkBox2, CheckBox checkBox3) {
        int total = contar * 20;

        if (checkBox.isChecked()) {
            total += 2 * contar; // Valor do Item 1
        }
        if (checkBox2.isChecked()) {
            total += 2 * contar; // Valor do Item 2
        }
        if (checkBox3.isChecked()) {
            total += 3 * contar; // Valor do Item 3
        }

        return total;
    }
    // Atualiza o total no TextView6
    private void ePe(TextView textView6, CheckBox checkBox, CheckBox checkBox2, CheckBox checkBox3) {
        int total = calcularTotal(checkBox, checkBox2, checkBox3);
        textView6.setText("Total: R$ " + total);
    }
    // Retorna o Nome escrito pelo cliente
    private String getNome(EditText editTextNome ){
        return editTextNome.getText().toString().trim();
    }
    // Altera a mensagem do botão checked
    private String getC(boolean isChecked) {
        return isChecked ? "Sim" : "Não";
    }
    // Retorna o valor da quantidade em textView4
    private String getT(TextView view) {
        return view.getText().toString();
    }
    // Retorna o valor em textView6
    private String ePe(TextView view) {
        return view.getText().toString();
    }

}